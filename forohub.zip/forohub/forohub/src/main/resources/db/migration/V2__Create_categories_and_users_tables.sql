CREATE TABLE categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    country VARCHAR(50) NOT NULL,
    profession VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE user_categories (
    user_id BIGINT,
    category_id BIGINT,
    PRIMARY KEY (user_id, category_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

INSERT INTO categories (name) VALUES
('Estudio'), ('Trabajo'), ('Filosofía'), ('Ciencia'),
('Cine'), ('Deportes'), ('Farándula'), ('Meditación');

INSERT INTO users (name, birth_date, country, profession, description) VALUES
('Sebastian Acosta', '1994-12-31', 'Colombia', 'Electromecánico', 'Soy un joven apasionado por la ciencia y la tecnología, así como de los deportes como el tenis de mesa, fútbol y el baloncesto.'),
('Gabriel Peña', '2024-05-15', 'Colombia', 'Ingeniero en Sistemas', 'Soy un adulto apasionado por la tecnología, la IA y el mundo de la informática y disfruto de practicar deportes como volar en parapente, jugar tenis de mesa y baloncesto.'),
('Mariana López', '1989-03-22', 'Mexico', 'Médica', 'Soy una profesional dedicada a la salud, apasionada por ayudar a los demás y amante de la lectura y el senderismo.'),
('Carlos Martínez', '1990-07-17', 'Argentina', 'Arquitecto', 'Soy un creativo con pasión por el diseño y la construcción de espacios innovadores, además disfruto del ciclismo y la fotografía.'),
('Lucía Gómez', '1989-10-10', 'Mexico', 'Abogada', 'Soy una defensora de la justicia, apasionada por el derecho y el debate, y me encanta bailar y practicar yoga.'),
('Andrés Torres', '1988-11-04', 'Argentina', 'Contador', 'Soy un experto en finanzas, dedicado y meticuloso, con un amor por los números y las matemáticas, y disfruto jugar ajedrez y correr maratones.'),
('Valentina Rodríguez', '1994-06-05', 'Colombia', 'Psicóloga', 'Soy una profesional de la salud mental, apasionada por entender el comportamiento humano y me encanta viajar y pintar.'),
('Fernando Ramírez', '1993-09-28', 'España', 'Ingeniero Civil', 'Soy un ingeniero civil comprometido con el desarrollo de infraestructuras sostenibles y me gusta la pesca y el senderismo.'),
('Isabella Sánchez', '1997-12-12', 'Colombia', 'Diseñadora Gráfica', 'Soy una creativa visual, apasionada por el diseño gráfico y la moda, y disfruto del cine y la fotografía.'),
('Ricardo González', '1985-01-25', 'España', 'Profesor', 'Soy un educador dedicado, apasionado por la enseñanza y la formación de nuevas generaciones, y me encanta leer y tocar la guitarra.');

-- Insertar relaciones entre usuarios y categorías
INSERT INTO user_categories (user_id, category_id)
SELECT u.id, c.id
FROM users u, categories c
WHERE
    (u.name = 'Sebastian Acosta' AND c.name IN ('Deportes', 'Ciencia')) OR
    (u.name = 'Gabriel Peña' AND c.name IN ('Ciencia', 'Deportes')) OR
    (u.name = 'Mariana López' AND c.name IN ('Ciencia', 'Filosofía')) OR
    (u.name = 'Carlos Martínez' AND c.name IN ('Trabajo', 'Deportes')) OR
    (u.name = 'Lucía Gómez' AND c.name IN ('Trabajo', 'Filosofía')) OR
    (u.name = 'Andrés Torres' AND c.name IN ('Trabajo', 'Deportes')) OR
    (u.name = 'Valentina Rodríguez' AND c.name IN ('Ciencia', 'Filosofía')) OR
    (u.name = 'Fernando Ramírez' AND c.name IN ('Trabajo', 'Deportes')) OR
    (u.name = 'Isabella Sánchez' AND c.name IN ('Trabajo', 'Cine')) OR
    (u.name = 'Ricardo González' AND c.name IN ('Trabajo', 'Filosofía'));