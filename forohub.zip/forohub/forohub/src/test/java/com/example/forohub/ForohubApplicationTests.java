package com.example.forohub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForohubApplicationTests {

	@Test
	void contextLoads() {
	}

}
